"""Thin async wrapper around the official `mcp` SDK (APIM-hosted MCP over HTTP)."""
from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager

from mcp import ClientSession
from mcp.client.sse import sse_client
from mcp.client.streamable_http import streamablehttp_client

from .config import Config


def run_async(coro):
    return asyncio.run(coro)


def explain(e: BaseException) -> str:
    """Unwrap anyio/ExceptionGroup noise into a readable message."""
    subs = getattr(e, "exceptions", None)
    if subs:
        return "; ".join(explain(s) for s in subs)
    return f"{type(e).__name__}: {e}"


def build_headers(cfg: Config, token: str | None) -> dict:
    h = {}
    if token:
        h["Authorization"] = f"Bearer {token}"
    if cfg.apim_subscription_key:
        h["Ocp-Apim-Subscription-Key"] = cfg.apim_subscription_key
    if cfg.extra_headers.strip():
        h.update(json.loads(cfg.extra_headers))
    return h


@asynccontextmanager
async def mcp_session(cfg: Config, token: str | None):
    if not cfg.mcp_url:
        raise ValueError("MCP server URL is not configured (Settings > APIM MCP).")
    headers = build_headers(cfg, token)
    if cfg.mcp_transport == "sse":
        async with sse_client(cfg.mcp_url, headers=headers) as (r, w):
            async with ClientSession(r, w) as s:
                await s.initialize()
                yield s
    else:
        async with streamablehttp_client(cfg.mcp_url, headers=headers) as (r, w, _):
            async with ClientSession(r, w) as s:
                await s.initialize()
                yield s


def result_to_text(res) -> str:
    parts = []
    for c in res.content:
        t = getattr(c, "text", None)
        parts.append(t if t is not None else json.dumps(c.model_dump(), default=str))
    text = "\n".join(parts)
    if not text and getattr(res, "structuredContent", None):
        text = json.dumps(res.structuredContent)
    return text


async def list_tools(cfg: Config, token: str | None) -> list[dict]:
    async with mcp_session(cfg, token) as s:
        res = await s.list_tools()
    return [
        {"name": t.name, "description": t.description or "", "schema": t.inputSchema or {}}
        for t in res.tools
    ]


async def call_tool(cfg: Config, token: str | None, name: str, args: dict) -> tuple[str, bool]:
    async with mcp_session(cfg, token) as s:
        res = await s.call_tool(name, args)
    return result_to_text(res), bool(res.isError)
