"""Entra ID sign-in with MSAL (authorization code flow + PKCE, token cache on disk)."""
from __future__ import annotations

import json

import msal

from .config import STATE_DIR, Config

CACHE_FILE = STATE_DIR / "token_cache.bin"
FLOWS_FILE = STATE_DIR / "flows.json"
RESERVED = {"openid", "profile", "offline_access"}


def _scopes(cfg: Config) -> list[str]:
    s = [x for x in cfg.scopes.replace(",", " ").split() if x.lower() not in RESERVED]
    return s or ["User.Read"]


def _cache() -> msal.SerializableTokenCache:
    STATE_DIR.mkdir(exist_ok=True)
    c = msal.SerializableTokenCache()
    if CACHE_FILE.exists():
        c.deserialize(CACHE_FILE.read_text())
    return c


def _save(c: msal.SerializableTokenCache) -> None:
    if c.has_state_changed:
        CACHE_FILE.write_text(c.serialize())


def _app(cfg: Config, cache):
    authority = f"https://login.microsoftonline.com/{cfg.tenant_id}"
    if cfg.client_secret:
        return msal.ConfidentialClientApplication(
            cfg.client_id, authority=authority, client_credential=cfg.client_secret, token_cache=cache
        )
    return msal.PublicClientApplication(cfg.client_id, authority=authority, token_cache=cache)


def _flows() -> dict:
    return json.loads(FLOWS_FILE.read_text()) if FLOWS_FILE.exists() else {}


def begin_login(cfg: Config) -> str:
    """Returns the Microsoft sign-in URL. The flow is stored on disk because the
    browser redirect starts a fresh Streamlit session."""
    app = _app(cfg, _cache())
    flow = app.initiate_auth_code_flow(_scopes(cfg), redirect_uri=cfg.redirect_uri, prompt="select_account")
    flows = _flows()
    flows[flow["state"]] = flow
    STATE_DIR.mkdir(exist_ok=True)
    FLOWS_FILE.write_text(json.dumps(dict(list(flows.items())[-5:])))
    return flow["auth_uri"]


def complete_login(cfg: Config, params: dict) -> dict:
    flows = _flows()
    flow = flows.pop(params.get("state", ""), None)
    if flow is None:
        return {"error": "expired", "error_description": "Login session expired. Please try again."}
    FLOWS_FILE.write_text(json.dumps(flows))
    cache = _cache()
    try:
        result = _app(cfg, cache).acquire_token_by_auth_code_flow(flow, params)
    except ValueError as e:
        return {"error": "state_mismatch", "error_description": str(e)}
    _save(cache)
    return result


def user_from_result(result: dict) -> dict:
    claims = result.get("id_token_claims", {})
    return {"name": claims.get("name", ""), "username": claims.get("preferred_username", "")}


def _silent(cfg: Config):
    if not (cfg.tenant_id and cfg.client_id):
        return None, None
    cache = _cache()
    app = _app(cfg, cache)
    accounts = app.get_accounts()
    if not accounts:
        return None, None
    res = app.acquire_token_silent(_scopes(cfg), account=accounts[0])
    _save(cache)
    if res and "access_token" in res:
        return accounts[0], res
    return None, None


def silent_user(cfg: Config) -> dict | None:
    acct, res = _silent(cfg)
    if not acct:
        return None
    name = res.get("id_token_claims", {}).get("name") or acct["username"]
    return {"name": name, "username": acct["username"]}


def get_access_token(cfg: Config) -> str | None:
    _, res = _silent(cfg)
    return res["access_token"] if res else None


def logout(cfg: Config) -> None:
    if CACHE_FILE.exists():
        CACHE_FILE.unlink()
