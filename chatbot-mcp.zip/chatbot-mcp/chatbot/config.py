"""Settings persisted to config.json (local only, git-ignored). Env/.env is a fallback."""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = ROOT / "config.json"
STATE_DIR = ROOT / ".state"
DEFAULT_TOOLS = ["get_account_data", "get_project_data", "list_projects", "get_estimate"]

load_dotenv(ROOT / ".env")


@dataclass
class Config:
    # Entra ID
    auth_enabled: bool = True
    tenant_id: str = ""
    client_id: str = ""
    client_secret: str = ""  # leave empty for a public client (PKCE)
    redirect_uri: str = "http://localhost:8501"
    scopes: str = ""  # e.g. api://<apim-api-app-id>/.default
    # Azure APIM MCP server
    mcp_url: str = ""
    mcp_transport: str = "streamable-http"  # or "sse"
    apim_subscription_key: str = ""
    extra_headers: str = ""  # JSON object
    # LLM
    llm_provider: str = "openai"  # or "azure"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    azure_endpoint: str = ""
    azure_api_key: str = ""
    azure_api_version: str = "2024-10-21"
    azure_deployment: str = ""
    system_prompt: str = (
        "You are a helpful assistant. Use the available tools to fetch real data "
        "before answering questions about accounts, projects and estimates. "
        "Never invent data; say when a tool returned nothing."
    )
    selected_tools: list = field(default_factory=list)


def load_config() -> Config:
    data = {}
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text())
        except json.JSONDecodeError:
            data = {}
    names = {f.name for f in fields(Config)}
    cfg = Config(**{k: v for k, v in data.items() if k in names})
    for f in fields(Config):  # env fallback for empty string fields
        if isinstance(getattr(cfg, f.name), str) and not getattr(cfg, f.name):
            env = os.getenv(f.name.upper())
            if env:
                setattr(cfg, f.name, env)
    return cfg


def save_config(cfg: Config) -> None:
    CONFIG_FILE.write_text(json.dumps(asdict(cfg), indent=2))
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except OSError:
        pass
