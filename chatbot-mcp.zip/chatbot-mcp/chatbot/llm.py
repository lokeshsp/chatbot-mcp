"""Chat loop: LLM function calling -> MCP tool calls -> final answer."""
from __future__ import annotations

import json

from openai import NOT_GIVEN, AsyncAzureOpenAI, AsyncOpenAI

from .config import Config
from .mcp_client import mcp_session, result_to_text

MAX_STEPS = 8
MAX_RESULT_CHARS = 20000


def make_client(cfg: Config):
    if cfg.llm_provider == "azure":
        if not (cfg.azure_endpoint and cfg.azure_api_key and cfg.azure_deployment):
            raise ValueError("Azure OpenAI endpoint, key and deployment are required (Settings > LLM).")
        client = AsyncAzureOpenAI(
            azure_endpoint=cfg.azure_endpoint, api_key=cfg.azure_api_key, api_version=cfg.azure_api_version
        )
        return client, cfg.azure_deployment
    if not cfg.openai_api_key:
        raise ValueError("OpenAI API key is required (Settings > LLM).")
    return AsyncOpenAI(api_key=cfg.openai_api_key), cfg.openai_model


def to_openai_tool(t: dict) -> dict:
    schema = dict(t.get("schema") or {})
    schema.setdefault("type", "object")
    schema.setdefault("properties", {})
    return {
        "type": "function",
        "function": {"name": t["name"], "description": t.get("description", ""), "parameters": schema},
    }


async def run_turn(cfg: Config, token: str | None, history: list, tools: list[dict]):
    """Appends to `history` (OpenAI message format). Returns (final_text, trace)."""
    client, model = make_client(cfg)
    oa_tools = [to_openai_tool(t) for t in tools] or NOT_GIVEN
    allowed = {t["name"] for t in tools}
    trace = []
    system = {"role": "system", "content": cfg.system_prompt}

    async with mcp_session(cfg, token) as session:
        for _ in range(MAX_STEPS):
            resp = await client.chat.completions.create(
                model=model, messages=[system, *history], tools=oa_tools
            )
            msg = resp.choices[0].message
            if not msg.tool_calls:
                text = msg.content or ""
                history.append({"role": "assistant", "content": text})
                return text, trace

            history.append(
                {
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                        }
                        for tc in msg.tool_calls
                    ],
                }
            )
            for tc in msg.tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except json.JSONDecodeError:
                    args = {}
                if name not in allowed:
                    text, is_err = f"Tool '{name}' is not enabled.", True
                else:
                    try:
                        res = await session.call_tool(name, args)
                        text, is_err = result_to_text(res), bool(res.isError)
                    except Exception as e:  # surface tool failures to the model
                        text, is_err = f"Tool call failed: {e}", True
                text = text[:MAX_RESULT_CHARS]
                trace.append({"name": name, "args": args, "result": text, "error": is_err})
                history.append({"role": "tool", "tool_call_id": tc.id, "content": text})

    final = "I hit the tool-call limit before finishing. Try a narrower question."
    history.append({"role": "assistant", "content": final})
    return final, trace
