# chatbot-mcp

Local AI chatbot (Streamlit) that signs in with **Microsoft Entra ID**, discovers tools from an
**Azure APIM-hosted MCP server**, lets you pick which tools to use, and calls them from a real
chat via OpenAI / Azure OpenAI function calling.

## Run (Python 3.10+)

    ./run.sh        # macOS/Linux
    run.bat         # Windows

Opens http://localhost:8501. First launch lands on **Settings**.

## 1. Entra ID app registration

1. Entra admin center > App registrations > New registration.
2. Redirect URI: `http://localhost:8501`
   - No client secret: platform **Mobile and desktop applications** (public client + PKCE).
   - With client secret: platform **Web**; create a secret and paste it in Settings.
3. Copy **Directory (tenant) ID** and **Application (client) ID** into Settings > Entra ID.
4. Scope: the API your APIM validates, e.g. `api://<apim-api-app-id>/.default`
   (grant the app permission to it). The resulting access token is sent as `Authorization: Bearer`.

## 2. APIM MCP server

Settings > APIM MCP: set the MCP endpoint URL, transport (`streamable-http` or `sse`), and optionally
an `Ocp-Apim-Subscription-Key` or extra JSON headers. Use **Test MCP connection**.

## 3. LLM

Settings > LLM: OpenAI key + model, or Azure OpenAI endpoint/key/deployment.

## 4. Use it

- **Tools**: discovers tools, tick the ones the chat may call (defaults: `get_account_data`,
  `get_project_data`, `list_projects`, `get_estimate` when present). Each tool has a "try it" runner.
- **Chat**: the model picks tools from your selection; every call and result is shown in expandable cards.

## Notes

- `config.json` (secrets) and `.state/` (token cache) are local and git-ignored.
- Single-user local app; do not expose it on a network.
- Optional `.env` values (see `.env.example`) are used when a Settings field is empty.

## Test without APIM

    python dev/mock_mcp_server.py        # http://localhost:9000/mcp

In Settings: turn off "Require Entra ID login", set the MCP URL above, add an LLM key.

## Push to GitHub

    git init && git add . && git commit -m "Initial commit: MCP chatbot"
    git branch -M main
    git remote add origin https://github.com/lokeshsp/chatbot-mcp.git
    git push -u origin main
