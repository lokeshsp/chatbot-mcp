"""MCP Chatbot: Streamlit UI (Entra ID login, APIM MCP tools, OpenAI / Azure OpenAI)."""
import json

import streamlit as st

from chatbot import auth
from chatbot.config import DEFAULT_TOOLS, load_config, save_config
from chatbot.llm import run_turn
from chatbot.mcp_client import call_tool, explain, list_tools, run_async

st.set_page_config(page_title="MCP Chatbot", page_icon="🤖", layout="wide")
cfg = load_config()
ss = st.session_state
ss.setdefault("tools", [])
ss.setdefault("history", [])
ss.setdefault("ui", [])

# ---------- OAuth redirect callback ----------
qp = dict(st.query_params)
if "state" in qp and ("code" in qp or "error" in qp):
    if "error" in qp:
        ss["auth_error"] = qp.get("error_description") or qp["error"]
    else:
        result = auth.complete_login(cfg, qp)
        if "access_token" in result:
            ss["user"] = auth.user_from_result(result)
        else:
            ss["auth_error"] = result.get("error_description") or result.get("error", "Login failed")
    st.query_params.clear()
    st.rerun()

user = None
if cfg.auth_enabled:
    user = ss.get("user") or auth.silent_user(cfg)
    if user:
        ss["user"] = user


# ---------- helpers ----------
def gate():
    """Stops the page unless the user is signed in (or auth is disabled)."""
    if not cfg.auth_enabled or user:
        return
    if err := ss.pop("auth_error", None):
        st.error(f"Sign-in failed: {err}")
    if not (cfg.tenant_id and cfg.client_id):
        st.warning("Configure Entra ID first: Settings > Entra ID.")
        st.stop()
    url = auth.begin_login(cfg)
    st.info("Sign in with Microsoft Entra ID to continue.")
    st.markdown(
        f'<a href="{url}" target="_self" style="display:inline-block;padding:.6rem 1.2rem;'
        f'background:#0078d4;color:#fff;border-radius:6px;text-decoration:none;font-weight:600">'
        f"Sign in with Microsoft</a>",
        unsafe_allow_html=True,
    )
    st.stop()


def get_token():
    if not cfg.auth_enabled:
        return None
    tok = auth.get_access_token(cfg)
    if not tok:
        ss.pop("user", None)
        st.warning("Session expired. Please sign in again.")
        st.rerun()
    return tok


def discover():
    try:
        with st.spinner("Discovering tools..."):
            ss["tools"] = run_async(list_tools(cfg, get_token()))
        if not cfg.selected_tools:
            cfg.selected_tools = [t["name"] for t in ss["tools"] if t["name"] in DEFAULT_TOOLS]
            save_config(cfg)
        return True
    except Exception as e:
        st.error(f"Discovery failed: {explain(e)}")
        return False


def render_trace(trace):
    for t in trace:
        icon = "⚠️" if t["error"] else "🔧"
        with st.expander(f"{icon} {t['name']}"):
            st.caption("Arguments")
            st.code(json.dumps(t["args"], indent=2), language="json")
            st.caption("Result")
            st.code(t["result"][:4000])


# ---------- pages ----------
def page_settings():
    st.header("⚙️ Settings")
    st.caption("Saved locally to config.json (git-ignored). Secrets are stored in plain text on this machine.")
    with st.form("settings"):
        t_auth, t_mcp, t_llm = st.tabs(["🔐 Entra ID", "🔌 APIM MCP", "🧠 LLM"])
        with t_auth:
            auth_enabled = st.toggle("Require Entra ID login", cfg.auth_enabled)
            tenant = st.text_input("Tenant ID (GUID or domain)", cfg.tenant_id)
            client_id = st.text_input("Client (application) ID", cfg.client_id)
            secret = st.text_input(
                "Client secret (optional, leave empty for public client + PKCE)",
                cfg.client_secret,
                type="password",
            )
            redirect = st.text_input("Redirect URI", cfg.redirect_uri, help="Must match the app registration exactly.")
            scopes = st.text_input(
                "API scope(s) for the MCP/APIM API",
                cfg.scopes,
                placeholder="api://<apim-app-id>/.default",
                help="Space-separated. The access token for these scopes is sent to APIM as a Bearer token.",
            )
        with t_mcp:
            mcp_url = st.text_input("MCP server URL", cfg.mcp_url, placeholder="https://<apim>.azure-api.net/<api>/mcp")
            transport = st.selectbox(
                "Transport", ["streamable-http", "sse"], index=["streamable-http", "sse"].index(cfg.mcp_transport)
            )
            sub_key = st.text_input("APIM subscription key (optional)", cfg.apim_subscription_key, type="password")
            extra = st.text_area("Extra headers (JSON, optional)", cfg.extra_headers, height=80, placeholder='{"x-foo": "bar"}')
        with t_llm:
            provider = st.selectbox("Provider", ["openai", "azure"], index=["openai", "azure"].index(cfg.llm_provider))
            st.markdown("**OpenAI**")
            oai_key = st.text_input("OpenAI API key", cfg.openai_api_key, type="password")
            oai_model = st.text_input("Model", cfg.openai_model)
            st.markdown("**Azure OpenAI**")
            az_ep = st.text_input("Endpoint", cfg.azure_endpoint, placeholder="https://<resource>.openai.azure.com")
            az_key = st.text_input("Azure API key", cfg.azure_api_key, type="password")
            az_dep = st.text_input("Deployment name", cfg.azure_deployment)
            az_ver = st.text_input("API version", cfg.azure_api_version)
            sys_prompt = st.text_area("System prompt", cfg.system_prompt, height=120)
        saved = st.form_submit_button("💾 Save settings", type="primary")

    if saved:
        if extra.strip():
            try:
                json.loads(extra)
            except json.JSONDecodeError:
                st.error("Extra headers must be valid JSON.")
                return
        cfg.auth_enabled, cfg.tenant_id, cfg.client_id = auth_enabled, tenant.strip(), client_id.strip()
        cfg.client_secret, cfg.redirect_uri, cfg.scopes = secret.strip(), redirect.strip(), scopes.strip()
        cfg.mcp_url, cfg.mcp_transport = mcp_url.strip(), transport
        cfg.apim_subscription_key, cfg.extra_headers = sub_key.strip(), extra.strip()
        cfg.llm_provider, cfg.openai_api_key, cfg.openai_model = provider, oai_key.strip(), oai_model.strip()
        cfg.azure_endpoint, cfg.azure_api_key = az_ep.strip(), az_key.strip()
        cfg.azure_deployment, cfg.azure_api_version = az_dep.strip(), az_ver.strip()
        cfg.system_prompt = sys_prompt
        save_config(cfg)
        st.success("Saved.")

    st.divider()
    if st.button("🔎 Test MCP connection"):
        gate()
        try:
            tools = run_async(list_tools(cfg, get_token()))
            st.success(f"Connected. {len(tools)} tool(s): " + ", ".join(t["name"] for t in tools))
        except Exception as e:
            st.error(explain(e))


def page_tools():
    gate()
    st.header("🧰 Tools")
    if not cfg.mcp_url:
        st.warning("Set the MCP server URL in Settings first.")
        return
    c1, c2 = st.columns([1, 4])
    if c1.button("🔄 Discover tools") or (not ss["tools"] and discover()):
        discover()
    if not ss["tools"]:
        return
    c2.caption(f"{len(ss['tools'])} tools discovered. Tick the ones the chatbot may call.")

    selected = []
    for t in ss["tools"]:
        with st.container(border=True):
            on = st.checkbox(f"**{t['name']}**", value=t["name"] in cfg.selected_tools, key=f"sel_{t['name']}")
            if on:
                selected.append(t["name"])
            st.caption(t["description"] or "No description")
            with st.expander("Schema / try it"):
                st.code(json.dumps(t["schema"], indent=2), language="json")
                args_txt = st.text_area("Arguments (JSON)", "{}", key=f"args_{t['name']}", height=80)
                if st.button("Run", key=f"run_{t['name']}"):
                    try:
                        text, err = run_async(call_tool(cfg, get_token(), t["name"], json.loads(args_txt or "{}")))
                        (st.error if err else st.success)("Tool returned an error" if err else "OK")
                        st.code(text[:6000])
                    except Exception as e:
                        st.error(explain(e))
    if sorted(selected) != sorted(cfg.selected_tools):
        cfg.selected_tools = selected
        save_config(cfg)
        st.toast("Tool selection saved")


def page_chat():
    gate()
    st.header("💬 Chat")
    if not cfg.mcp_url:
        st.warning("Set the MCP server URL in Settings first.")
        return
    if not ss["tools"] and not discover():
        return
    tools = [t for t in ss["tools"] if t["name"] in cfg.selected_tools]
    st.caption("Tools enabled: " + (", ".join(t["name"] for t in tools) or "none (pick some in Tools)"))
    if st.button("🗑️ Clear chat"):
        ss["history"], ss["ui"] = [], []
        st.rerun()

    for m in ss["ui"]:
        with st.chat_message(m["role"]):
            render_trace(m.get("trace", []))
            st.markdown(m["content"])

    if prompt := st.chat_input("Ask about accounts, projects, estimates..."):
        ss["ui"].append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            work = [*ss["history"], {"role": "user", "content": prompt}]
            try:
                with st.spinner("Thinking..."):
                    text, trace = run_async(run_turn(cfg, get_token(), work, tools))
                ss["history"] = work
            except Exception as e:
                text, trace = f"⚠️ {explain(e)}", []
            render_trace(trace)
            st.markdown(text)
        ss["ui"].append({"role": "assistant", "content": text, "trace": trace})


# ---------- sidebar / routing ----------
with st.sidebar:
    st.title("🤖 MCP Chatbot")
    if cfg.auth_enabled and user:
        st.success(f"{user['name']}\n\n{user['username']}")
        if st.button("Sign out"):
            auth.logout(cfg)
            for k in ("user", "tools", "history", "ui"):
                ss.pop(k, None)
            st.rerun()
    elif not cfg.auth_enabled:
        st.caption("Auth disabled (local dev mode)")
    needs_setup = not (cfg.mcp_url and (cfg.client_id or not cfg.auth_enabled))
    page = st.radio("Navigate", ["💬 Chat", "🧰 Tools", "⚙️ Settings"], index=2 if needs_setup else 0)

{"💬 Chat": page_chat, "🧰 Tools": page_tools, "⚙️ Settings": page_settings}[page]()
