"""Tiny local MCP server with the four sample tools, for testing without APIM.
Run: python dev/mock_mcp_server.py  ->  http://localhost:9000/mcp  (Auth: disable Entra login in Settings)."""
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("mock-projects", port=9000)
PROJECTS = [{"id": "P-1", "name": "Alpha", "account_id": "A-1"}, {"id": "P-2", "name": "Beta", "account_id": "A-1"}]


@mcp.tool()
def get_account_data(account_id: str) -> dict:
    """Get account details by id."""
    return {"id": account_id, "name": "Contoso Ltd", "tier": "Gold"}


@mcp.tool()
def list_projects(account_id: str = "") -> list:
    """List projects, optionally for one account."""
    return [p for p in PROJECTS if not account_id or p["account_id"] == account_id]


@mcp.tool()
def get_project_data(project_id: str) -> dict:
    """Get project details by id."""
    return next((p for p in PROJECTS if p["id"] == project_id), {"error": "not found"})


@mcp.tool()
def get_estimate(project_id: str) -> dict:
    """Get the estimate for a project."""
    return {"project_id": project_id, "hours": 320, "cost_usd": 48000}


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
